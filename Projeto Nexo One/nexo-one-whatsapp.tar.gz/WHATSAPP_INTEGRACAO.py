# =============================================================================
# INTEGRAÇÃO WhatsApp Evolution API no server.py
# =============================================================================

# 1. ADICIONAR NO TOPO DO server.py (após imports existentes):
"""
from whatsapp_evolution import whatsapp_router
"""

# 2. ADICIONAR APÓS app = FastAPI(...):
"""
app.include_router(whatsapp_router)
"""

# 3. VARIÁVEIS DE AMBIENTE (.env):
"""
EVOLUTION_URL=https://socialgrizzlybear-evolution.cloudfy.live
EVOLUTION_KEY=0iGsRJBF2EgcducrjqkMz3IgQyosoKmR
EVOLUTION_INSTANCE=erpnexoone
NEXO_WHATSAPP=5511947726031
"""

# 4. CONFIGURAR WEBHOOK NA EVOLUTION API:
# Acessar: https://socialgrizzlybear-evolution.cloudfy.live/manager
# Instância: erpnexoone
# Configurações → Webhook
# URL: https://SEU_DOMINIO/api/v1/whatsapp/webhook
# Eventos ativar: messages.upsert

# =============================================================================
# ENDPOINTS DISPONÍVEIS
# =============================================================================
"""
POST /api/v1/whatsapp/send-verification
    Envia código de 6 dígitos para o número do usuário
    Body: { phone, tenant_slug, business_type }

POST /api/v1/whatsapp/verify-code
    Valida o código digitado pelo usuário
    Body: { phone, code }

POST /api/v1/whatsapp/webhook
    Recebe mensagens da Evolution API automaticamente
    Detecta código de 6 dígitos e valida automaticamente

POST /api/v1/whatsapp/send-approval
    Envia link de aprovação de orçamento (Mecânica)
    Query: phone, customer_name, os_number, approval_url, total_value

GET  /api/v1/whatsapp/status
    Verifica se a instância está conectada
"""

# =============================================================================
# FLUXO COMPLETO DE VERIFICAÇÃO
# =============================================================================
"""
1. Usuário informa telefone no cadastro
2. Sistema chama POST /api/v1/whatsapp/send-verification
3. Evolution API envia mensagem com código de 6 dígitos para o usuário
4. Usuário vê o código e digita no sistema
   OU responde a mensagem com o código (webhook automático)
5. Sistema chama POST /api/v1/whatsapp/verify-code
6. Código válido → trial liberado automaticamente
"""
